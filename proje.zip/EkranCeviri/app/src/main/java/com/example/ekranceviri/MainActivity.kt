package com.example.ekranceviri

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("ec", Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        fun label(t: String) = TextView(this).apply {
            text = t; textSize = 16f; setTypeface(typeface, Typeface.BOLD); setPadding(0, pad, 0, 0)
        }
        fun sw(t: String, key: String, def: Boolean) = Switch(this).apply {
            text = t
            isChecked = prefs.getBoolean(key, def)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply() }
        }

        col.addView(TextView(this).apply { text = "Ekran Çeviri"; textSize = 26f })
        col.addView(label("Ekrandaki yazı türü"))
        col.addView(radio(listOf("Latin (İngilizce, Almanca, İspanyolca...)", "Çince", "Japonca", "Korece", "Hintçe"), "script", 0))
        col.addView(label("Kaynak dil (Latin için)"))
        val names = arrayOf("Otomatik", "İngilizce", "Almanca", "Fransızca", "İspanyolca", "İtalyanca", "Portekizce")
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, names)
            setSelection(prefs.getInt("src", 0))
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    prefs.edit().putInt("src", pos).apply()
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        })
        col.addView(label("Canlı mod hızı"))
        col.addView(radio(listOf("Hızlı (1 sn)", "Normal (2,5 sn)", "Yavaş (5 sn)"), "speed", 1))
        col.addView(label("Seçenekler"))
        col.addView(sw("Kullanıcı adlarını / @ / # etiketlerini çevirme", "skipNames", true))
        col.addView(sw("Tek kelimelik yazıları çevirme (isimler için, sadece Latin)", "skipSingle", false))
        col.addView(sw("Satır satır çevir (oyun menüleri için)", "lineMode", false))

        col.addView(Button(this).apply { text = "Başlat"; setOnClickListener { start() } })
        col.addView(Button(this).apply {
            text = "Durdur"
            setOnClickListener { stopService(Intent(this@MainActivity, ScreenTranslateService::class.java)) }
        })
        col.addView(TextView(this).apply {
            text = "Ayarı değiştirdiysen Durdur'a basıp tekrar Başlat'a bas."
            setPadding(0, pad / 2, 0, 0)
        })
        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun radio(items: List<String>, key: String, def: Int): RadioGroup {
        val g = RadioGroup(this)
        items.forEachIndexed { i, s -> g.addView(RadioButton(this).apply { id = 1000 + i; text = s }) }
        g.check(1000 + prefs.getInt(key, def))
        g.setOnCheckedChangeListener { _, id -> prefs.edit().putInt(key, id - 1000).apply() }
        return g
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Diğer uygulamaların üzerinde gösterme iznini aç, sonra tekrar Başlat'a bas", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenTranslateService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
