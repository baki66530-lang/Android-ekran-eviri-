package com.example.ekranceviri

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.StaticLayout
import android.text.TextPaint
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class ScreenTranslateService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var overlay: OverlayView
    private lateinit var panel: LinearLayout
    private lateinit var recognizer: TextRecognizer
    private var liveBtn: TextView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var live = false
    private var busy = false
    private var dead = false
    private var warned = false
    private var gen = 0
    private var lastHash = 0L

    // ayarlar
    private var script = 0
    private var skipNames = true
    private var skipSingle = false
    private var lineMode = false
    private var delayMs = 2500L
    private var forcedSrc: String? = null
    private var fallbackLang = "en"

    private val identifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.4f).build()
    )
    private val translators = HashMap<String, Translator>()
    private val cache = HashMap<String, String>() // "" = çevirme

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNotification()
        if (projection != null) return START_NOT_STICKY
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            intent?.getParcelableExtra<Intent>("data")
        }
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val p = getSharedPreferences("ec", Context.MODE_PRIVATE)
        script = p.getInt("script", 0)
        skipNames = p.getBoolean("skipNames", true)
        skipSingle = p.getBoolean("skipSingle", false)
        lineMode = p.getBoolean("lineMode", false)
        delayMs = longArrayOf(1000L, 2500L, 5000L)[p.getInt("speed", 1).coerceIn(0, 2)]
        val sc = arrayOf("auto", "en", "de", "fr", "es", "it", "pt")[p.getInt("src", 0).coerceIn(0, 6)]
        forcedSrc = if (script == 0 && sc != "auto") sc else null
        fallbackLang = when (script) { 1 -> "zh"; 2 -> "ja"; 3 -> "ko"; 4 -> "hi"; else -> "en" }
        recognizer = when (script) {
            1 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            2 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            3 -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            4 -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
            else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        }

        val dm = DisplayMetrics()
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        val mp = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)
        val r = ImageReader.newInstance(dm.widthPixels, dm.heightPixels, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = mp.createVirtualDisplay(
            "ekranceviri", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler
        )

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        overlay = OverlayView(this)
        wm.addView(
            overlay,
            WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
        )
        buildPanel()
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("ec", "Ekran Çeviri", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "ec")
            .setContentTitle("Ekran Çeviri çalışıyor")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    // ---------- Panel ----------
    private fun buildPanel() {
        val d = resources.displayMetrics.density
        panel = LinearLayout(this).apply {
            background = GradientDrawable().apply { setColor(0xE6222222.toInt()); cornerRadius = 24 * d }
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
        }
        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 14f
            val q = (11 * d).toInt()
            setPadding(q, q, q, q)
            setOnClickListener { onClick() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * d).toInt(); y = (200 * d).toInt() }

        val handle = btn("⠿") {}
        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(panel, lp)
                    }
                }
                return true
            }
        })
        val lb = btn("▶ Canlı") { toggleLive() }
        liveBtn = lb
        panel.addView(handle)
        panel.addView(btn("Çevir") { capture(true) {} })
        panel.addView(lb)
        panel.addView(btn("Temizle") { clearAll() })
        panel.addView(btn("✕") { stopSelf() })
        wm.addView(panel, lp)
    }

    private fun toggleLive() {
        live = !live
        liveBtn?.text = if (live) "■ Durdur" else "▶ Canlı"
        if (live) loop()
    }

    private fun loop() {
        if (!live || dead) return
        capture(false) { handler.postDelayed({ loop() }, delayMs) }
    }

    private fun clearAll() {
        gen++
        live = false
        lastHash = 0L
        liveBtn?.text = "▶ Canlı"
        overlay.setItems(emptyList())
    }

    // ---------- Yakala -> OCR -> Çevir ----------
    private fun capture(force: Boolean, done: () -> Unit) {
        if (busy || dead) { done(); return }
        busy = true
        warned = false
        val g = ++gen
        overlay.visibility = View.INVISIBLE
        panel.visibility = View.INVISIBLE
        handler.postDelayed({ grab(g, 0, force, done) }, 220)
    }

    private fun finish(done: () -> Unit) { busy = false; done() }

    private fun restore() {
        if (dead) return
        overlay.visibility = View.VISIBLE
        panel.visibility = View.VISIBLE
    }

    private fun grab(g: Int, tries: Int, force: Boolean, done: () -> Unit) {
        if (dead) return
        val img = reader?.acquireLatestImage()
        if (img == null) {
            if (tries < 12) handler.postDelayed({ grab(g, tries + 1, force, done) }, 120)
            else { restore(); finish(done) }
            return
        }
        val bmp = try { img.toBitmap() } finally { img.close() }
        restore()
        val h = hash(bmp)
        if (!force && h == lastHash && overlay.count() > 0) { bmp.recycle(); finish(done); return }
        lastHash = h
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t -> translateAll(bmp, t, g, done) }
            .addOnFailureListener { bmp.recycle(); finish(done) }
    }

    private fun hash(b: Bitmap): Long {
        var h = 1125899906842597L
        val sx = maxOf(1, b.width / 48)
        val sy = maxOf(1, b.height / 96)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) {
                h = 31 * h + (b.getPixel(x, y) and 0xF0F0F0F0.toInt())
                x += sx
            }
            y += sy
        }
        return h
    }

    private class Piece(val text: String, val box: Rect, val lines: Int)

    private fun looksLikeName(s: String): Boolean {
        if (s.contains(' ')) return false
        if (s.startsWith("@") || s.startsWith("#")) return true
        return s.any { it == '_' || it == '.' || it.isDigit() }
    }

    private fun translateAll(bmp: Bitmap, t: Text, g: Int, done: () -> Unit) {
        val latin = script == 0
        val pieces = ArrayList<Piece>()
        for (b in t.textBlocks) {
            if (lineMode) {
                for (l in b.lines) l.boundingBox?.let { pieces.add(Piece(l.text.trim(), it, 1)) }
            } else {
                b.boundingBox?.let { pieces.add(Piece(b.text.replace('\n', ' ').trim(), it, maxOf(1, b.lines.size))) }
            }
        }
        val use = pieces.filter { p ->
            p.text.any { it.isLetter() } &&
                !(latin && skipNames && looksLikeName(p.text)) &&
                !(latin && skipSingle && !p.text.contains(' '))
        }
        if (use.isEmpty()) {
            bmp.recycle()
            if (g == gen && !dead) overlay.setItems(emptyList())
            finish(done)
            return
        }
        val items = ArrayList<Item>()
        var pending = use.size
        for (p in use) {
            val bg = bgColor(bmp, p.box)
            val fg = fgColor(bmp, p.box, bg)
            val lineH = p.box.height().toFloat() / p.lines
            translate(p.text) { tr ->
                if (tr != null) items.add(Item(p.box, tr, bg, fg, lineH))
                pending--
                if (pending == 0) {
                    bmp.recycle()
                    if (g == gen && !dead) overlay.setItems(items)
                    finish(done)
                }
            }
        }
    }

    private fun translate(text: String, cb: (String?) -> Unit) {
        cache[text]?.let { cb(it.ifEmpty { null }); return }
        val forced = forcedSrc
        if (forced != null) { runTranslate(text, forced, cb); return }
        identifier.identifyLanguage(text).addOnCompleteListener { task ->
            var code = if (task.isSuccessful) task.result else "und"
            if (code == "und") code = fallbackLang
            runTranslate(text, code, cb)
        }
    }

    private fun runTranslate(text: String, code: String, cb: (String?) -> Unit) {
        if (code == "tr") { cache[text] = ""; cb(null); return }
        val src = TranslateLanguage.fromLanguageTag(code)
        if (src == null) { cb(null); return }
        val tr = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(TranslateLanguage.TURKISH).build()
            )
        }
        tr.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                tr.translate(text)
                    .addOnSuccessListener { r ->
                        if (r.equals(text, true)) { cache[text] = ""; cb(null) } else { cache[text] = r; cb(r) }
                    }
                    .addOnFailureListener { cb(null) }
            }
            .addOnFailureListener {
                if (!warned) {
                    warned = true
                    Toast.makeText(this, "Dil modeli indirilemedi (internet gerekli)", Toast.LENGTH_SHORT).show()
                }
                cb(null)
            }
    }

    // ---------- Renkler: arka plan = kutunun çevresindeki en yaygın renk ----------
    private fun bgColor(bmp: Bitmap, r: Rect): Int {
        val counts = HashMap<Int, IntArray>()
        fun add(x: Int, y: Int) {
            val c = bmp.getPixel(x.coerceIn(0, bmp.width - 1), y.coerceIn(0, bmp.height - 1))
            val key = ((Color.red(c) shr 5) shl 6) or ((Color.green(c) shr 5) shl 3) or (Color.blue(c) shr 5)
            val a = counts.getOrPut(key) { IntArray(4) }
            a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
        }
        val m = 3
        for (i in 0..8) {
            val x = r.left + r.width() * i / 8
            add(x, r.top - m); add(x, r.bottom + m)
        }
        for (i in 0..4) {
            val y = r.top + r.height() * i / 4
            add(r.left - m, y); add(r.right + m, y)
        }
        val best = counts.values.maxByOrNull { it[0] }!!
        return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }

    // Yazı rengi = kutu içinde arka plandan en uzak piksel (renkli yazılar için); okunmuyorsa siyah/beyaz
    private fun fgColor(bmp: Bitmap, r: Rect, bg: Int): Int {
        var best = bg
        var bd = -1
        for (i in 0 until 12) for (j in 0 until 4) {
            val c = bmp.getPixel(
                (r.left + r.width() * i / 11).coerceIn(0, bmp.width - 1),
                (r.top + r.height() * (j * 2 + 1) / 8).coerceIn(0, bmp.height - 1)
            )
            val dr = Color.red(c) - Color.red(bg)
            val dg = Color.green(c) - Color.green(bg)
            val db = Color.blue(c) - Color.blue(bg)
            val dd = dr * dr + dg * dg + db * db
            if (dd > bd) { bd = dd; best = c }
        }
        val l1 = lum(best); val l2 = lum(bg)
        val ratio = (maxOf(l1, l2) + 0.05) / (minOf(l1, l2) + 0.05)
        return if (ratio >= 3.0) best else if (l2 > 0.5) Color.BLACK else Color.WHITE
    }

    override fun onDestroy() {
        dead = true
        live = false
        handler.removeCallbacksAndMessages(null)
        runCatching { wm.removeView(overlay) }
        runCatching { wm.removeView(panel) }
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        translators.values.forEach { it.close() }
        if (::recognizer.isInitialized) recognizer.close()
        identifier.close()
        super.onDestroy()
    }
}

private fun lum(c: Int): Double {
    fun f(v: Int): Double {
        val s = v / 255.0
        return if (s <= 0.03928) s / 12.92 else Math.pow((s + 0.055) / 1.055, 2.4)
    }
    return 0.2126 * f(Color.red(c)) + 0.7152 * f(Color.green(c)) + 0.0722 * f(Color.blue(c))
}

private fun Image.toBitmap(): Bitmap {
    val plane = planes[0]
    val rowPad = plane.rowStride - plane.pixelStride * width
    val full = Bitmap.createBitmap(width + rowPad / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
    full.copyPixelsFromBuffer(plane.buffer)
    return if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, width, height)
}

data class Item(val box: Rect, val text: String, val bg: Int, val fg: Int, val lineH: Float)

class OverlayView(ctx: Context) : View(ctx) {
    private var items: List<Item> = emptyList()
    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val d = ctx.resources.displayMetrics.density

    fun setItems(l: List<Item>) { items = l; invalidate() }
    fun count() = items.size

    override fun onDraw(c: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        c.translate(-loc[0].toFloat(), -loc[1].toFloat())
        for (i in items) {
            val r = RectF(i.box).apply { inset(-5f * d, -2f * d) }
            bgP.color = i.bg or (0xFF shl 24)
            c.drawRoundRect(r, 6 * d, 6 * d, bgP)
            tp.color = i.fg
            val w = maxOf(1, (r.width() - 4 * d).toInt())
            var size = (i.lineH * 0.75f).coerceIn(9 * d, 28 * d)
            var lay = layoutOf(i.text, size, w)
            while (lay.height > r.height() && size > 9 * d) {
                size -= d
                lay = layoutOf(i.text, size, w)
            }
            c.save()
            c.clipRect(r)
            c.translate(r.left + 2 * d, r.top + maxOf(0f, (r.height() - lay.height) / 2))
            lay.draw(c)
            c.restore()
        }
    }

    private fun layoutOf(t: String, size: Float, w: Int): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(t, 0, t.length, tp, w).build()
    }
}
